<?php
  
  include 'conexion_be.php';

  $nombre_completo = $_POST['nombre_completo'];
  $correo = $_POST['correo'];
  $usuario = $_POST['usuario'];
  $contrasena = $_POST['contrasena'];
  $contrasena = hash('sha512', $contrasena);


$query = "INSERT INTO usuarios(nombre_completo, correo , usuario , contrasena) 
          VALUES('$nombre_completo', '$correo', '$usuario', '$contrasena')";
  
  //Verificar que el correo no se repita en la base de datos
  $verificar_correo = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo='$correo'");
  if (isset($_POST['nombre_completo'])) {
    $nombre_completo = $_POST['nombre_completo'];
    $correo = $_POST['correo'];
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    

    if(empty($nombre_completo)){
      echo '
           <script>
            alert("Por favor ingresa un nombre");
            window.location = "../indexx.php";
           </script>
           ';
    }else {
      if (strlen($nombre_completo) > 15) {
        echo '
           <script>
            alert("Por favor ingresa un nombre");
            window.location = "../indexx.php";
           </script>
           ';
      }
    }

    if(empty($correo)){
      echo '
           <script>
            alert("Por favor ingresa un nombre");
            window.location = "../indexx.php";
           </script>
           ';
    }else {
      if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        echo '
           <script>
            alert("El correo Ingresado es incorrecto");
            window.location = "../indexx.php";
           </script>
           ';
      }
    }


  }

  if (mysqli_num_rows($verificar_correo) > 0) {
      echo '
           <script>
            alert("Este correo ya esta registrado, intenta con otro diferente");
            window.location = "../indexx.php";
           </script>
           ';
           exit();
  }
  //Verificar que el nombre de usuario no se repita en la base de datos
  $verificar_usuario = mysqli_query($conexion, "SELECT * FROM usuarios WHERE usuario='$usuario'");

  if (mysqli_num_rows($verificar_usuario) > 0) {
      echo '
           <script>
            alert("Este usuario ya esta registrado, intenta con otro diferente");
            window.location = "../indexx.php";
           </script>
           ';
           exit();
  }

  $ejecutar = mysqli_query($conexion, $query);

    if ($ejecutar) {
        echo '
           <script>   
               alert("Usuario almacenado exitosamente");
               window.location = "../indexx.php";
           </script>
        
        ';
    }else {
       echo '  
       <script>   
       alert("Intentelo denuevo");
       window.location = "../indexx.php";
      </script> 
       ';
    }

    mysqli_close($conexion);
?>