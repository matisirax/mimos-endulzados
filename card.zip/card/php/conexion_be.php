<?php 



$conexion = mysqli_connect("localhost", "root" ,"", "login_register_db") ;
/*/
if($conexion){
    echo 'Conectado exitosamente a la base de datos';


}else {
    echo 'no se a podido conectar a la bd';
}
*/

?>



